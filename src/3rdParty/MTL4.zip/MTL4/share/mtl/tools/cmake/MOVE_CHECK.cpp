struct dings
{
    dings(dings&&) {}
};

int main()
{
    return 0;
}
